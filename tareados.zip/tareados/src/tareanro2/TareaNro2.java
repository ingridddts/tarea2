package tareanro2;

public class TareaNro2 {

    public static void main(String[] args) throws PagoIncorrectoException, PagoInsuficienteException, NoHayProductoException {
        // TODO code application logic here
        System.out.println("Precio Bebida : 3000");
        Ventana v= new Ventana();
    }
    
}
