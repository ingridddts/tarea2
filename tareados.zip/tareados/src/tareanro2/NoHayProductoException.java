package tareanro2;

public class NoHayProductoException extends Exception {
    public NoHayProductoException(String msg){
        super(msg);
    }
}
