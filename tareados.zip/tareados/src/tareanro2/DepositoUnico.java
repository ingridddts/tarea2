package tareanro2;

import java.awt.Color;
import java.awt.Graphics;

public class DepositoUnico {
   Bebida be;
   private int x,y;
   //Depositopara una bebida
   public DepositoUnico(int x, int y){
       this.x = x; 
       this.y = y;
   } 
   //se agrega una bebida y se guarda en la variable    
   public void addBebida(Bebida b){
       be = b;
   }
   //Devuelve la bebida y luego loa elimina del deposito 
   public Bebida getBebida(){
       Bebida b = be;
       be=null;
       return b;
   }
   //verifica si hay una bebida, si lo hay representara gfrafivamente la bebida
   public void paint(Graphics g){
        g.setColor(Color.white);
        g.drawRect(x+230, y+470, 150,33);
        g.setColor(Color.black);
        g.fillRect(x+231, y+471, 149, 32);
        if(be!=null){
            be.setXY(x+231, y+470);
            be.paint(g);
        }
    }
}
