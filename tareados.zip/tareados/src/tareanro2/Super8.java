package tareanro2;

//Clase que hereda de clase abstracta dulce
public class Super8 extends Dulce{
    public  Super8(int i){
        super(i);
}
    public String sabor(){
        String s= "Super8";
        return s; //devuelve el nombre de su sabor
    } 
}
