package tareanro2;

public class PagoIncorrectoException extends Exception{
    public PagoIncorrectoException(String msg){
        super(msg);
    }
}

