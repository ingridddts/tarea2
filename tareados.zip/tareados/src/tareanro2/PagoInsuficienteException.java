package tareanro2;

public class PagoInsuficienteException extends Exception{
    public PagoInsuficienteException(String msg){
        super(msg);
    }
}